suites.c is a dynamicically written program where new test cases can be written
and added to as needed. When creating a new configure file for a test be sure
to use the exact formatting as the existing configure files. Reference test.conf
for an example.
